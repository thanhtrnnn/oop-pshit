package com.supermarket.model;

import java.util.Arrays;

/**
 * Represents the product categories supported by the supermarket application.
 */
public enum Category {
    HANG_THOI_TRANG("Hàng thời trang"),
    HANG_TIEU_DUNG("Hàng tiêu dùng"),
    HANG_DIEN_MAY("Hàng điện máy"),
    HANG_GIA_DUNG("Hàng gia dụng");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public static Category fromDisplayName(String name) {
        return Arrays.stream(values())
                .filter(category -> category.displayName.equalsIgnoreCase(name) || category.name().equalsIgnoreCase(name))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy nhóm hàng: " + name));
    }

    @Override
    public String toString() {
        return displayName;
    }
}
