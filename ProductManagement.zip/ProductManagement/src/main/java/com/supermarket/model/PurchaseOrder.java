package com.supermarket.model;

import java.util.Collections;
import java.util.List;

public class PurchaseOrder {
    private final Customer customer;
    private final List<PurchaseItem> items;

    public PurchaseOrder(Customer customer, List<PurchaseItem> items) {
        this.customer = customer;
        this.items = List.copyOf(items);
    }

    public Customer getCustomer() {
        return customer;
    }

    public List<PurchaseItem> getItems() {
        return Collections.unmodifiableList(items);
    }

    public double getTotalAmount() {
        return items.stream()
                .mapToDouble(PurchaseItem::getTotalPrice)
                .sum();
    }
}
