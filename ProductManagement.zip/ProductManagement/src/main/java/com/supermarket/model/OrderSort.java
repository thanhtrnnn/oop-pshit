package com.supermarket.model;

public enum OrderSort {
    ORIGINAL,
    BY_CUSTOMER_NAME,
    BY_PRODUCT_NAME
}
