package com.supermarket.model;

public class OrderDisplayRow {
    private final Customer customer;
    private final Product product;
    private final int quantity;

    public OrderDisplayRow(Customer customer, Product product, int quantity) {
        this.customer = customer;
        this.product = product;
        this.quantity = quantity;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getUnitPrice() {
        return product.getPrice();
    }

    public double getTotalPrice() {
        return getUnitPrice() * quantity;
    }
}
