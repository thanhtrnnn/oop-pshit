package com.supermarket.persistence;

import com.supermarket.exception.DataAccessException;
import com.supermarket.exception.ValidationException;
import com.supermarket.model.PurchaseRecord;
import com.supermarket.util.FileUtils;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class OrderRepository {
    private final Path filePath;

    public OrderRepository() {
        this(Paths.get("data", "QLBH.TXT"));
    }

    public OrderRepository(Path filePath) {
        this.filePath = filePath;
        FileUtils.ensureFileExists(filePath);
    }

    public List<PurchaseRecord> findAll() {
        List<String> lines = FileUtils.readAllLines(filePath);
        List<PurchaseRecord> records = new ArrayList<>();
        for (String line : lines) {
            if (line == null || line.isBlank()) {
                continue;
            }
            records.add(parseRecord(line));
        }
        return records;
    }

    public List<PurchaseRecord> findByCustomerId(int customerId) {
        return findAll().stream()
                .filter(record -> record.getCustomerId() == customerId)
                .collect(Collectors.toList());
    }

    public void save(PurchaseRecord record) {
        List<PurchaseRecord> existing = findAll();
    boolean duplicate = existing.stream()
        .anyMatch(item -> item.getCustomerId() == record.getCustomerId()
            && item.getProductId() == record.getProductId());
    if (duplicate) {
        throw new ValidationException("Khách hàng đã mua mặt hàng này trong danh sách");
    }
        FileUtils.appendLine(filePath, formatRecord(record));
    }

    public void replaceAll(List<PurchaseRecord> records) {
        List<String> lines = records.stream()
                .map(this::formatRecord)
                .collect(Collectors.toList());
        FileUtils.writeAllLines(filePath, lines);
    }

    private PurchaseRecord parseRecord(String line) {
        String[] parts = line.split("\\|");
        if (parts.length != 3) {
            throw new DataAccessException("Dòng dữ liệu mua hàng không hợp lệ: " + line, null);
        }
        try {
            int customerId = Integer.parseInt(parts[0]);
            int productId = Integer.parseInt(parts[1]);
            int quantity = Integer.parseInt(parts[2]);
            return new PurchaseRecord(customerId, productId, quantity);
        } catch (NumberFormatException e) {
            throw new DataAccessException("Không thể phân tích dữ liệu mua hàng: " + line, e);
        }
    }

    private String formatRecord(PurchaseRecord record) {
        return record.getCustomerId() + "|" + record.getProductId() + "|" + record.getQuantity();
    }
}
