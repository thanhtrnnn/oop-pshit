package com.supermarket.persistence;

import com.supermarket.exception.DataAccessException;
import com.supermarket.model.Customer;
import com.supermarket.util.FileUtils;
import com.supermarket.util.IdGenerator;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class CustomerRepository {
    private static final int MIN_CUSTOMER_ID = 10000;
    private static final int MAX_CUSTOMER_ID = 99999;

    private final Path filePath;

    public CustomerRepository() {
        this(Paths.get("data", "KH.TXT"));
    }

    public CustomerRepository(Path filePath) {
        this.filePath = filePath;
        FileUtils.ensureFileExists(filePath);
    }

    public List<Customer> findAll() {
        List<String> lines = FileUtils.readAllLines(filePath);
        List<Customer> customers = new ArrayList<>();
        for (String line : lines) {
            if (line == null || line.isBlank()) {
                continue;
            }
            customers.add(parseCustomer(line));
        }
        return customers;
    }

    public Optional<Customer> findById(int id) {
        return findAll().stream()
                .filter(customer -> customer.getId() == id)
                .findFirst();
    }

    public Customer save(Customer customer) {
        FileUtils.appendLine(filePath, formatCustomer(customer));
        return customer;
    }

    public int nextId() {
        List<Integer> ids = findAll().stream()
                .map(Customer::getId)
                .collect(Collectors.toList());
        return IdGenerator.nextId(ids, MIN_CUSTOMER_ID, MAX_CUSTOMER_ID);
    }

    private Customer parseCustomer(String line) {
        String[] parts = line.split("\\|");
        if (parts.length != 4) {
            throw new DataAccessException("Dòng dữ liệu khách hàng không hợp lệ: " + line, null);
        }
        try {
            int id = Integer.parseInt(parts[0]);
            String fullName = parts[1];
            String address = parts[2];
            String phone = parts[3];
            return new Customer(id, fullName, address, phone);
        } catch (NumberFormatException e) {
            throw new DataAccessException("Không thể phân tích dữ liệu khách hàng: " + line, e);
        }
    }

    private String formatCustomer(Customer customer) {
        return customer.getId() + "|" + customer.getFullName() + "|" + customer.getAddress() + "|" + customer.getPhoneNumber();
    }
}
