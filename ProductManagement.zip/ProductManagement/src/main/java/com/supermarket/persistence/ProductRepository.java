package com.supermarket.persistence;

import com.supermarket.exception.DataAccessException;
import com.supermarket.model.Category;
import com.supermarket.model.Product;
import com.supermarket.util.FileUtils;
import com.supermarket.util.IdGenerator;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ProductRepository {
    private static final int MIN_PRODUCT_ID = 1000;
    private static final int MAX_PRODUCT_ID = 9999;

    private final Path filePath;

    public ProductRepository() {
        this(Paths.get("data", "MH.TXT"));
    }

    public ProductRepository(Path filePath) {
        this.filePath = filePath;
        FileUtils.ensureFileExists(filePath);
    }

    public List<Product> findAll() {
        List<String> lines = FileUtils.readAllLines(filePath);
        List<Product> products = new ArrayList<>();
        for (String line : lines) {
            if (line == null || line.isBlank()) {
                continue;
            }
            products.add(parseProduct(line));
        }
        return products;
    }

    public Optional<Product> findById(int id) {
        return findAll().stream()
                .filter(product -> product.getId() == id)
                .findFirst();
    }

    public Product save(Product product) {
        FileUtils.appendLine(filePath, formatProduct(product));
        return product;
    }

    public int nextId() {
        List<Integer> ids = findAll().stream()
                .map(Product::getId)
                .collect(Collectors.toList());
        return IdGenerator.nextId(ids, MIN_PRODUCT_ID, MAX_PRODUCT_ID);
    }

    private Product parseProduct(String line) {
        String[] parts = line.split("\\|");
        if (parts.length != 4) {
            throw new DataAccessException("Dòng dữ liệu mặt hàng không hợp lệ: " + line, null);
        }
        try {
            int id = Integer.parseInt(parts[0]);
            String name = parts[1];
            Category category = Category.fromDisplayName(parts[2]);
            double price = Double.parseDouble(parts[3]);
            return new Product(id, name, category, price);
        } catch (NumberFormatException e) {
            throw new DataAccessException("Không thể phân tích dữ liệu mặt hàng: " + line, e);
        }
    }

    private String formatProduct(Product product) {
        return product.getId() + "|" + product.getName() + "|" + product.getCategory().getDisplayName() + "|" + product.getPrice();
    }
}
