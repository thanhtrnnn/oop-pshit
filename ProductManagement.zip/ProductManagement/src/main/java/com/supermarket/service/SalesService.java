package com.supermarket.service;

import com.supermarket.exception.DataAccessException;
import com.supermarket.exception.ValidationException;
import com.supermarket.model.Category;
import com.supermarket.model.Customer;
import com.supermarket.model.OrderDisplayRow;
import com.supermarket.model.OrderSort;
import com.supermarket.model.Product;
import com.supermarket.model.PurchaseItem;
import com.supermarket.model.PurchaseOrder;
import com.supermarket.model.PurchaseRecord;
import com.supermarket.persistence.CustomerRepository;
import com.supermarket.persistence.OrderRepository;
import com.supermarket.persistence.ProductRepository;
import com.supermarket.util.ValidationUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class SalesService {
    private static final int MAX_ITEMS_PER_CUSTOMER = 10;

    private final ProductRepository productRepository;
    private final CustomerRepository customerRepository;
    private final OrderRepository orderRepository;

    public SalesService(ProductRepository productRepository,
                        CustomerRepository customerRepository,
                        OrderRepository orderRepository) {
        this.productRepository = productRepository;
        this.customerRepository = customerRepository;
        this.orderRepository = orderRepository;
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Product addProduct(String name, Category category, double price) {
        String safeName = sanitize(name, "Tên hàng");
        if (category == null) {
            throw new ValidationException("Phải chọn nhóm hàng");
        }
        if (price <= 0) {
            throw new ValidationException("Giá bán phải lớn hơn 0");
        }
        int id = productRepository.nextId();
        Product product = new Product(id, safeName, category, roundMoney(price));
        return productRepository.save(product);
    }

    public Customer addCustomer(String fullName, String address, String phoneNumber) {
        String safeName = sanitize(fullName, "Họ tên");
        String safeAddress = sanitize(address, "Địa chỉ");
        String safePhone = ValidationUtils.validatePhoneNumber(phoneNumber);
        int id = customerRepository.nextId();
        Customer customer = new Customer(id, safeName, safeAddress, safePhone);
        return customerRepository.save(customer);
    }

    public void addPurchaseRecord(int customerId, int productId, int quantity) {
        Customer customer = requireCustomer(customerId);
        Product product = requireProduct(productId);
        ValidationUtils.requirePositiveQuantity(quantity, "Số lượng");

        List<PurchaseRecord> existing = orderRepository.findByCustomerId(customerId);
        if (existing.size() >= MAX_ITEMS_PER_CUSTOMER) {
            throw new ValidationException("Mỗi khách hàng chỉ được mua tối đa " + MAX_ITEMS_PER_CUSTOMER + " mặt hàng khác nhau");
        }
        orderRepository.save(new PurchaseRecord(customer.getId(), product.getId(), quantity));
    }

    public List<OrderDisplayRow> getOrderDisplayRows(OrderSort sort) {
        Map<Integer, Customer> customers = getAllCustomers().stream()
                .collect(Collectors.toMap(Customer::getId, customer -> customer));
        Map<Integer, Product> products = getAllProducts().stream()
                .collect(Collectors.toMap(Product::getId, product -> product));

        List<OrderDisplayRow> rows = new ArrayList<>();
        for (PurchaseRecord record : orderRepository.findAll()) {
            Customer customer = customers.get(record.getCustomerId());
            Product product = products.get(record.getProductId());
            if (customer == null || product == null) {
                throw new DataAccessException("Dữ liệu mua hàng không đồng bộ", null);
            }
            rows.add(new OrderDisplayRow(customer, product, record.getQuantity()));
        }

        Comparator<OrderDisplayRow> comparator = switch (sort) {
            case BY_CUSTOMER_NAME -> Comparator.comparing(row -> row.getCustomer().getFullName().toLowerCase(Locale.ROOT));
            case BY_PRODUCT_NAME -> Comparator.comparing(row -> row.getProduct().getName().toLowerCase(Locale.ROOT));
            case ORIGINAL -> null;
        };

        if (comparator != null) {
            rows.sort(comparator);
        }
        return rows;
    }

    public PurchaseOrder buildInvoiceForCustomer(int customerId) {
        Customer customer = requireCustomer(customerId);
        Map<Integer, Product> productMap = getAllProducts().stream()
                .collect(Collectors.toMap(Product::getId, product -> product));
        List<PurchaseItem> items = orderRepository.findByCustomerId(customerId).stream()
                .map(record -> {
                    Product product = productMap.get(record.getProductId());
                    if (product == null) {
                        throw new DataAccessException("Không tìm thấy mặt hàng cho hóa đơn", null);
                    }
                    return new PurchaseItem(product, record.getQuantity());
                })
                .collect(Collectors.toList());
        if (items.isEmpty()) {
            throw new ValidationException("Khách hàng chưa có dữ liệu mua hàng");
        }
        return new PurchaseOrder(customer, items);
    }

    public Optional<Customer> findCustomerById(int customerId) {
        return customerRepository.findById(customerId);
    }

    public Optional<Product> findProductById(int productId) {
        return productRepository.findById(productId);
    }

    public void overwritePurchaseRecords(List<PurchaseRecord> records) {
        orderRepository.replaceAll(records);
    }

    private Customer requireCustomer(int customerId) {
        return findCustomerById(customerId)
                .orElseThrow(() -> new ValidationException("Không tìm thấy khách hàng với mã " + customerId));
    }

    private Product requireProduct(int productId) {
        return findProductById(productId)
                .orElseThrow(() -> new ValidationException("Không tìm thấy mặt hàng với mã " + productId));
    }

    private String sanitize(String value, String fieldName) {
        String trimmed = ValidationUtils.requireNotBlank(value, fieldName);
        if (trimmed.contains("|")) {
            throw new ValidationException(fieldName + " không được chứa ký tự '|");
        }
        return trimmed;
    }

    private double roundMoney(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
