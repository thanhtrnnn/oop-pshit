package com.supermarket;

import com.supermarket.persistence.CustomerRepository;
import com.supermarket.persistence.OrderRepository;
import com.supermarket.persistence.ProductRepository;
import com.supermarket.service.SalesService;
import com.supermarket.ui.MainFrame;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import java.util.Locale;

public class App {
    public static void main(String[] args) {
        Locale.setDefault(new Locale("vi", "VN"));
        setSystemLookAndFeel();

        SwingUtilities.invokeLater(() -> {
            SalesService service = new SalesService(
                    new ProductRepository(),
                    new CustomerRepository(),
                    new OrderRepository());
            MainFrame frame = new MainFrame(service);
            frame.setVisible(true);
        });
    }

    private static void setSystemLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            // Fallback to default look and feel if system L&F cannot be set
        }
    }
}
