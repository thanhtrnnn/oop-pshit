package com.supermarket.ui;

import com.supermarket.exception.DataAccessException;
import com.supermarket.exception.ValidationException;
import com.supermarket.model.Customer;
import com.supermarket.service.SalesService;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

public class CustomerPanel extends JPanel {
    private final SalesService salesService;
    private final Runnable dataChangedCallback;
    private final DefaultTableModel tableModel;
    private final JTable customerTable;
    private final JTextField nameField;
    private final JTextField addressField;
    private final JTextField phoneField;

    public CustomerPanel(SalesService salesService, Runnable dataChangedCallback) {
        this.salesService = salesService;
        this.dataChangedCallback = dataChangedCallback;
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Thêm khách hàng"));

        nameField = new JTextField(20);
        addressField = new JTextField(20);
        phoneField = new JTextField(15);

        JButton addButton = new JButton("Thêm");
        addButton.addActionListener(e -> handleAddCustomer());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Họ tên:"), gbc);
        gbc.gridx = 1;
        formPanel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Địa chỉ:"), gbc);
        gbc.gridx = 1;
        formPanel.add(addressField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Số điện thoại:"), gbc);
        gbc.gridx = 1;
        formPanel.add(phoneField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        formPanel.add(addButton, gbc);

        add(formPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{"Mã KH", "Họ tên", "Địa chỉ", "Số điện thoại"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        customerTable = new JTable(tableModel);
        add(new JScrollPane(customerTable), BorderLayout.CENTER);

        add(createFooterPanel(), BorderLayout.SOUTH);

        refreshTable();
    }

    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Nguồn dữ liệu"),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)));

        JLabel hintLabel = new JLabel("Danh sách được đọc từ file data/KH.TXT. Nhấn \"Tải lại\" sau khi chỉnh sửa file.");
        JButton reloadButton = new JButton("Tải lại từ file");
        reloadButton.addActionListener(e -> handleReloadFromFile());

        panel.add(hintLabel, BorderLayout.CENTER);
        panel.add(reloadButton, BorderLayout.EAST);
        return panel;
    }

    private void handleAddCustomer() {
        try {
            Customer customer = salesService.addCustomer(
                    nameField.getText(),
                    addressField.getText(),
                    phoneField.getText());
            JOptionPane.showMessageDialog(this, "Đã thêm khách hàng mã " + customer.getId());
            clearForm();
            refreshTable();
            notifyDataChanged();
        } catch (ValidationException ex) {
            showError(ex.getMessage());
        } catch (DataAccessException ex) {
            showError(ex.getMessage());
        }
    }

    private void handleReloadFromFile() {
        refreshTable();
        notifyDataChanged();
    }

    private void refreshTable() {
        List<Customer> customers = salesService.getAllCustomers();
        tableModel.setRowCount(0);
        for (Customer customer : customers) {
            tableModel.addRow(new Object[]{
                    String.format("%05d", customer.getId()),
                    customer.getFullName(),
                    customer.getAddress(),
                    customer.getPhoneNumber()
            });
        }
    }

    private void clearForm() {
        nameField.setText("");
        addressField.setText("");
        phoneField.setText("");
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Lỗi", JOptionPane.ERROR_MESSAGE);
    }

    private void notifyDataChanged() {
        if (dataChangedCallback != null) {
            dataChangedCallback.run();
        }
    }
}
