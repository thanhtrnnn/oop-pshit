package com.supermarket.ui;

import com.supermarket.model.PurchaseItem;
import com.supermarket.model.PurchaseOrder;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.Font;
import java.text.NumberFormat;
import java.util.Locale;

public class InvoiceDialog extends JDialog {
    public InvoiceDialog(PurchaseOrder order) {
        setTitle("Hóa đơn khách hàng " + order.getCustomer().getFullName());
    setModal(true);
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(500, 600);
        setLayout(new BorderLayout());

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        textArea.setText(buildInvoice(order));

        add(new JScrollPane(textArea), BorderLayout.CENTER);
    }

    private String buildInvoice(PurchaseOrder order) {
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));
        StringBuilder builder = new StringBuilder();
        builder.append("HÓA ĐƠN BÁN HÀNG\n");
        builder.append("Khách hàng: ").append(order.getCustomer().getFullName()).append('\n');
        builder.append("Địa chỉ: ").append(order.getCustomer().getAddress()).append('\n');
        builder.append("Số điện thoại: ").append(order.getCustomer().getPhoneNumber()).append('\n');
        builder.append("\n");
        builder.append(String.format("%-4s %-30s %-8s %-15s\n", "STT", "Mặt hàng", "SL", "Thành tiền"));
        builder.append("-------------------------------------------------------------------\n");

        int index = 1;
        for (PurchaseItem item : order.getItems()) {
            builder.append(String.format("%-4d %-30s %-8d %-15s\n",
                    index++,
                    item.getProduct().getName(),
                    item.getQuantity(),
                    currencyFormat.format(item.getTotalPrice())));
        }
        builder.append("-------------------------------------------------------------------\n");
        builder.append(String.format("%-43s %-15s\n", "TỔNG CỘNG", currencyFormat.format(order.getTotalAmount())));
        return builder.toString();
    }
}
