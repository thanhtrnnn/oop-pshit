package com.supermarket.ui;

import com.supermarket.exception.DataAccessException;
import com.supermarket.exception.ValidationException;
import com.supermarket.model.Category;
import com.supermarket.model.Product;
import com.supermarket.service.SalesService;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

public class ProductPanel extends JPanel {
    private final SalesService salesService;
    private final Runnable dataChangedCallback;
    private final DefaultTableModel tableModel;
    private final JTable productTable;
    private final JTextField nameField;
    private final JComboBox<Category> categoryCombo;
    private final JTextField priceField;

    public ProductPanel(SalesService salesService, Runnable dataChangedCallback) {
        this.salesService = salesService;
        this.dataChangedCallback = dataChangedCallback;
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Thêm mặt hàng"));

        nameField = new JTextField(20);
        categoryCombo = new JComboBox<>(Category.values());
        priceField = new JTextField(10);

        JButton addButton = new JButton("Thêm");
        addButton.addActionListener(e -> handleAddProduct());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Tên hàng:"), gbc);
        gbc.gridx = 1;
        formPanel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Nhóm hàng:"), gbc);
        gbc.gridx = 1;
        formPanel.add(categoryCombo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Giá bán:"), gbc);
        gbc.gridx = 1;
        formPanel.add(priceField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        formPanel.add(addButton, gbc);

        add(formPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{"Mã hàng", "Tên hàng", "Nhóm hàng", "Giá bán"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        productTable = new JTable(tableModel);
        add(new JScrollPane(productTable), BorderLayout.CENTER);

        add(createFooterPanel(), BorderLayout.SOUTH);

        refreshTable();
    }

    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Nguồn dữ liệu"),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)));

        JLabel hintLabel = new JLabel("Danh sách được đọc từ file data/MH.TXT. Nhấn \"Tải lại\" sau khi chỉnh sửa file.");
        JButton reloadButton = new JButton("Tải lại từ file");
        reloadButton.addActionListener(e -> handleReloadFromFile());

        panel.add(hintLabel, BorderLayout.CENTER);
        panel.add(reloadButton, BorderLayout.EAST);
        return panel;
    }

    private void handleAddProduct() {
        try {
            String name = nameField.getText();
            Category category = (Category) categoryCombo.getSelectedItem();
            double price = Double.parseDouble(priceField.getText().trim());
            Product product = salesService.addProduct(name, category, price);
            JOptionPane.showMessageDialog(this, "Đã thêm mặt hàng mã " + product.getId());
            clearForm();
            refreshTable();
            notifyDataChanged();
        } catch (NumberFormatException ex) {
            showError("Giá bán phải là số hợp lệ");
        } catch (ValidationException ex) {
            showError(ex.getMessage());
        } catch (DataAccessException ex) {
            showError(ex.getMessage());
        }
    }

    private void handleReloadFromFile() {
        refreshTable();
        notifyDataChanged();
    }

    private void refreshTable() {
        List<Product> products = salesService.getAllProducts();
        tableModel.setRowCount(0);
        for (Product product : products) {
            tableModel.addRow(new Object[]{
                    String.format("%04d", product.getId()),
                    product.getName(),
                    product.getCategory().getDisplayName(),
                    String.format("%,.2f", product.getPrice())
            });
        }
    }

    private void clearForm() {
        nameField.setText("");
        categoryCombo.setSelectedIndex(0);
        priceField.setText("");
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Lỗi", JOptionPane.ERROR_MESSAGE);
    }

    private void notifyDataChanged() {
        if (dataChangedCallback != null) {
            dataChangedCallback.run();
        }
    }
}
