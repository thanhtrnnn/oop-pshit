package com.supermarket.ui;

import com.supermarket.service.SalesService;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import java.awt.BorderLayout;

public class MainFrame extends JFrame {
    private final SalesService salesService;
    private OrderPanel orderPanel;

    public MainFrame(SalesService salesService) {
        super("Quản lý bán hàng siêu thị");
        this.salesService = salesService;
        initialize();
    }

    private void initialize() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setSize(1000, 700);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();
        orderPanel = new OrderPanel(salesService);
        ProductPanel productPanel = new ProductPanel(salesService, orderPanel::reloadData);
        CustomerPanel customerPanel = new CustomerPanel(salesService, orderPanel::reloadData);

        tabbedPane.addTab("Mặt hàng", productPanel);
        tabbedPane.addTab("Khách hàng", customerPanel);
        tabbedPane.addTab("Danh sách mua hàng", orderPanel);

        tabbedPane.addChangeListener(e -> {
            if (tabbedPane.getSelectedComponent() == orderPanel) {
                orderPanel.reloadData();
            }
        });

        add(tabbedPane, BorderLayout.CENTER);
    }
}
