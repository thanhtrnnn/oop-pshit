package com.supermarket.ui;

import com.supermarket.exception.DataAccessException;
import com.supermarket.exception.ValidationException;
import com.supermarket.model.Customer;
import com.supermarket.model.OrderDisplayRow;
import com.supermarket.model.OrderSort;
import com.supermarket.model.Product;
import com.supermarket.model.PurchaseOrder;
import com.supermarket.service.SalesService;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class OrderPanel extends JPanel {
    private final SalesService salesService;
    private final JComboBox<Customer> customerCombo;
    private final JComboBox<Product> productCombo;
    private final JSpinner quantitySpinner;
    private final DefaultTableModel tableModel;
    private OrderSort currentSort = OrderSort.ORIGINAL;

    public OrderPanel(SalesService salesService) {
        this.salesService = salesService;
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Lập danh sách mua hàng"));

        customerCombo = new JComboBox<>();
        productCombo = new JComboBox<>();
        quantitySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 1000, 1));

        JButton addButton = new JButton("Thêm vào danh sách");
        addButton.addActionListener(e -> handleAddPurchase());

        JButton invoiceButton = new JButton("Lập hóa đơn");
        invoiceButton.addActionListener(e -> handleInvoice());

        JButton sortByCustomerButton = new JButton("Sắp xếp theo khách hàng");
        sortByCustomerButton.addActionListener(e -> {
            currentSort = OrderSort.BY_CUSTOMER_NAME;
            refreshTable();
        });

        JButton sortByProductButton = new JButton("Sắp xếp theo mặt hàng");
        sortByProductButton.addActionListener(e -> {
            currentSort = OrderSort.BY_PRODUCT_NAME;
            refreshTable();
        });

        JButton reloadButton = new JButton("Hiển thị gốc");
        reloadButton.addActionListener(e -> {
            currentSort = OrderSort.ORIGINAL;
            refreshTable();
        });

        inputPanel.add(new JLabel("Khách hàng:"));
        inputPanel.add(customerCombo);
        inputPanel.add(new JLabel("Mặt hàng:"));
        inputPanel.add(productCombo);
        inputPanel.add(new JLabel("Số lượng:"));
        inputPanel.add(quantitySpinner);
        inputPanel.add(addButton);
        inputPanel.add(invoiceButton);
        inputPanel.add(sortByCustomerButton);
        inputPanel.add(sortByProductButton);
        inputPanel.add(reloadButton);

        add(inputPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{
                "Mã KH", "Tên khách hàng", "Mã hàng", "Tên mặt hàng", "Số lượng", "Đơn giá", "Thành tiền"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable orderTable = new JTable(tableModel);
        add(new JScrollPane(orderTable), BorderLayout.CENTER);

        refreshCombos();
        refreshTable();
    }

    public void reloadData() {
        refreshTable();
    }

    private void refreshCombos() {
        Customer selectedCustomer = (Customer) customerCombo.getSelectedItem();
        Integer selectedCustomerId = selectedCustomer != null ? selectedCustomer.getId() : null;
        customerCombo.removeAllItems();
        for (Customer customer : salesService.getAllCustomers()) {
            customerCombo.addItem(customer);
            if (selectedCustomerId != null && customer.getId() == selectedCustomerId) {
                customerCombo.setSelectedItem(customer);
            }
        }

        Product selectedProduct = (Product) productCombo.getSelectedItem();
        Integer selectedProductId = selectedProduct != null ? selectedProduct.getId() : null;
        productCombo.removeAllItems();
        for (Product product : salesService.getAllProducts()) {
            productCombo.addItem(product);
            if (selectedProductId != null && product.getId() == selectedProductId) {
                productCombo.setSelectedItem(product);
            }
        }
    }

    private void refreshTable() {
        refreshCombos();
        List<OrderDisplayRow> rows = salesService.getOrderDisplayRows(currentSort);
        tableModel.setRowCount(0);
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));
        for (OrderDisplayRow row : rows) {
            tableModel.addRow(new Object[]{
                    String.format("%05d", row.getCustomer().getId()),
                    row.getCustomer().getFullName(),
                    String.format("%04d", row.getProduct().getId()),
                    row.getProduct().getName(),
                    row.getQuantity(),
                    currencyFormat.format(row.getUnitPrice()),
                    currencyFormat.format(row.getTotalPrice())
            });
        }
    }

    private void handleAddPurchase() {
        Customer customer = (Customer) customerCombo.getSelectedItem();
        Product product = (Product) productCombo.getSelectedItem();
        if (customer == null) {
            showError("Vui lòng chọn khách hàng");
            return;
        }
        if (product == null) {
            showError("Vui lòng chọn mặt hàng");
            return;
        }
        int quantity = (int) quantitySpinner.getValue();
        try {
            salesService.addPurchaseRecord(customer.getId(), product.getId(), quantity);
            JOptionPane.showMessageDialog(this, "Đã thêm vào danh sách mua hàng");
            refreshTable();
        } catch (ValidationException ex) {
            showError(ex.getMessage());
        } catch (DataAccessException ex) {
            showError(ex.getMessage());
        }
    }

    private void handleInvoice() {
        Customer customer = (Customer) customerCombo.getSelectedItem();
        if (customer == null) {
            showError("Vui lòng chọn khách hàng để lập hóa đơn");
            return;
        }
        try {
            PurchaseOrder order = salesService.buildInvoiceForCustomer(customer.getId());
            InvoiceDialog dialog = new InvoiceDialog(order);
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);
        } catch (ValidationException ex) {
            showError(ex.getMessage());
        } catch (DataAccessException ex) {
            showError(ex.getMessage());
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Lỗi", JOptionPane.ERROR_MESSAGE);
    }
}
