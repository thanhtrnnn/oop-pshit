package com.supermarket.util;

import com.supermarket.exception.DataAccessException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

public final class FileUtils {
    private FileUtils() {
    }

    public static void ensureFileExists(Path path) {
        try {
            if (Files.notExists(path)) {
                Files.createDirectories(path.getParent());
                Files.createFile(path);
            }
        } catch (IOException e) {
            throw new DataAccessException("Không thể tạo file: " + path, e);
        }
    }

    public static List<String> readAllLines(Path path) {
        try {
            return Files.readAllLines(path, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new DataAccessException("Không thể đọc file: " + path, e);
        }
    }

    public static void writeAllLines(Path path, List<String> lines) {
        try {
            Files.write(path, lines, StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        } catch (IOException e) {
            throw new DataAccessException("Không thể ghi file: " + path, e);
        }
    }

    public static void appendLine(Path path, String line) {
        try {
            Files.writeString(path, line + System.lineSeparator(), StandardCharsets.UTF_8, StandardOpenOption.APPEND);
        } catch (IOException e) {
            throw new DataAccessException("Không thể ghi thêm vào file: " + path, e);
        }
    }
}
