package com.supermarket.util;

import com.supermarket.exception.ValidationException;

import java.util.Collection;

public final class IdGenerator {
    private IdGenerator() {
    }

    public static int nextId(Collection<Integer> existingIds, int minInclusive, int maxInclusive) {
        int max = existingIds.stream().mapToInt(Integer::intValue).max().orElse(minInclusive - 1);
        int candidate = Math.max(minInclusive, max + 1);
        if (candidate > maxInclusive) {
            throw new ValidationException("Đã vượt quá giới hạn mã cho phép");
        }
        return candidate;
    }
}
