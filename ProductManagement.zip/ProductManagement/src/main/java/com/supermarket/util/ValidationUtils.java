package com.supermarket.util;

import com.supermarket.exception.ValidationException;

public final class ValidationUtils {
    private ValidationUtils() {
    }

    public static String requireNotBlank(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new ValidationException(fieldName + " không được để trống");
        }
        return value.trim();
    }

    public static double parsePositiveDouble(String value, String fieldName) {
        requireNotBlank(value, fieldName);
        try {
            double parsed = Double.parseDouble(value.trim());
            if (parsed <= 0) {
                throw new ValidationException(fieldName + " phải lớn hơn 0");
            }
            return parsed;
        } catch (NumberFormatException e) {
            throw new ValidationException(fieldName + " phải là số hợp lệ");
        }
    }

    public static int requirePositiveQuantity(int quantity, String fieldName) {
        if (quantity <= 0) {
            throw new ValidationException(fieldName + " phải lớn hơn 0");
        }
        return quantity;
    }

    public static String validatePhoneNumber(String value) {
        String trimmed = requireNotBlank(value, "Số điện thoại");
        if (!trimmed.matches("\\d{9,11}")) {
            throw new ValidationException("Số điện thoại phải có 9-11 chữ số");
        }
        return trimmed;
    }
}
